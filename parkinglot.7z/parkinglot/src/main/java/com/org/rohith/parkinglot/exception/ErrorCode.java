/**
 * 
 */
package com.org.rohith.parkinglot.exception;

public enum ErrorCode {
	PARKING_ALREADY_EXIST("Parking already created"), PARKING_NOT_EXIST_ERROR("Parking Does not Exist"),
	INVALID_VALUE("{variable} value is incorrect"), INVALID_FILE("Invalid File"), PROCESSING_ERROR("Processing Error "),
	INVALID_REQUEST("Invalid Request");

	private String message = "";

	private ErrorCode(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
