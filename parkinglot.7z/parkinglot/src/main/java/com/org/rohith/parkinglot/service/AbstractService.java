package com.org.rohith.parkinglot.service;

public interface AbstractService
{
	
}
